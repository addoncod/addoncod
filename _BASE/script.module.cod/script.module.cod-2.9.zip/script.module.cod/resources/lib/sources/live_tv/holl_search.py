# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from resources.lib.modules import m3u_parser,parental,control
from resources.lib.modules.log_utils import log
import sys,os,xbmc,base64


AddonPath = control.addonPath
IconPath = AddonPath + "/resources/media/"
def icon_path(filename):
    return os.path.join(IconPath, filename)

class info():
    def __init__(self):
    	self.mode = 'holl_search'
        self.name = 'KODI GOOGLE (TV search)'
        self.icon = ''
        self.paginated = False
        self.categorized = False
        self.multilink = False

class main():
	def __init__(self,url = '68747470733A2F2F7261772E67697468756275736572636F6E74656E742E636F6D2F6164646F6E636F642F6164646F6E636F642F6D61696E2F44422F365A555538393030312E6462'.decode('hex')):
		self.base = '68747470733A2F2F7261772E67697468756275736572636F6E74656E742E636F6D2F6164646F6E636F642F6164646F6E636F642F6D61696E2F44422F365A555538393030312E6462'.decode('hex')
		self.url = url

	def channels(self):
		out = []
		keyboard = xbmc.Keyboard('', 'Pretraži TV,Film,Serije', False)
		keyboard.doModal()
		if keyboard.isConfirmed():
			query = keyboard.getText()
			tracks = m3u_parser.parseM3U(self.url)
			tracks = self.search_m3u(query,tracks)
			for track in tracks:
				title=track.title

				url=track.path
				img = icon_path(info().icon)
				out.append((url,title,img))
		return out

	def resolve(self,url):
		return url
	


	def search_m3u(self,query,shows):
	    words=query.lower().split(' ')
	    br=0
	    pom=0
	    out=[]
	    for show in shows:
	    	try:
	    		if 'ODRASLE' in show.title:
	    			if not parental.Parental().isVisible():
	    				break
	    	except:
	    		pass

	        for word in words:
	            try:
	                if word in show.title.lower():
	                    br+=1
	            except:
	                pass

	        if br>0:
	            tup=(br,pom)
	            out.append(tup)
	        br=0
	        pom+=1
	    from operator import itemgetter
	    out=sorted(out,key=lambda x: x[0], reverse=True)
	    outt=[]
	    for i in range(len(out)):
	    	index = out[i][1]
	    	track = shows[index]
	        outt.append(track)

	    return outt
