# -*- coding: utf-8 -*-

def parse_ustream(params):
    return "http://iphone-streaming.ustream.tv/ustreamVideo/" + params + "/streams/live/playlist.m3u8"