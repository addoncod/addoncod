import xbmc
import utils
import os
import xbmcgui
import sfile
import urllib
import urllib2
import time
import re
import downloader
import extractor
import xbmcvfs
import shutil
HOME        = xbmc.translatePath('special://home/userdata/')
done      =  os.path.join(HOME, 'done1.xml')
if os.path.exists(done):
    exit()
update = xbmcgui.Dialog().yesno("[COLOR red]C.O.D Installer[/COLOR]","[COLOR red]Ukoliko zelite instalirati ili azurirati pritisnite[/COLOR] [COLOR yellow]DA[/COLOR]","[COLOR white]C.O.D Instalator, za vise info...posjetite stranicu http://cod./center!![/COLOR]" ,"[COLOR blue]Ukoliko ste instalirali a nije vam potrebno azuriranje pristisnite[/COLOR] [COLOR yellow]NE[/COLOR]")
if update:
    xbmc.executebuiltin("Notification(HTTP://COD.CENTER, [B][COLOR=gold]Inicijalizacija...[/COLOR] -- [COLOR=red]Molimo pricekajte[/COLOR][/B],3000,)")
    xbmc.sleep(2000)
    xbmc.executebuiltin('RunAddon(script.c.o.d-installer)')
else: exit()